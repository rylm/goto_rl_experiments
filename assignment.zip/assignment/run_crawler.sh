#!/bin/bash
python crawler.py

