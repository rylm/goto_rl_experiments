#!/bin/bash
python pacman.py -p PacmanQAgent -x 1000 -n 1010 -l smallGrid

